# 实时语音情感分析系统

一个基于实时语音转文本和 DeepSeek API 的语音情感分析系统。

## 项目结构

```
audi_emotion/
├── project/          # 项目代码包
│   ├── __init__.py
│   └── main.py      # 主程序入口
├── resource/         # 资源文件包
│   ├── deepseek_api_key.txt  # DeepSeek API 密钥
│   └── emotion.txt           # 情感类别配置
├── audi_text/       # 语音转文本模块（第三方库）
├── requirements.txt # 项目依赖文件
├── setup.py         # 项目打包配置文件
└── README.md        # 项目说明文件
```

## 功能特性

- **实时语音转文本**：使用 `audi_text` 模块进行实时语音识别
- **情感分析**：通过 DeepSeek API 对转录文本进行情感分析
- **固定情感类别**：支持自定义情感类别（默认：愤怒、厌恶、恐惧、悲伤、惊喜）
- **模型问题识别**：自动识别并回答模型相关问题

## 安装依赖

```bash
pip install -r requirements.txt
```

## 配置

1. **配置 DeepSeek API 密钥**
   - 编辑 `resource/deepseek_api_key.txt`
   - 将您的 DeepSeek API 密钥写入文件

2. **配置情感类别**
   - 编辑 `resource/emotion.txt`
   - 每行一个情感类别，或使用空格分隔
   - 默认类别：愤怒 厌恶 恐惧 悲伤 惊喜

## 使用方法

### 方法一：直接运行

```bash
python project/main.py
```

### 方法二：使用打包后的命令（如果已安装）

```bash
audi-emotion
```

## 运行说明

1. 启动程序后，等待 "speak now" 提示
2. 开始说话，程序会自动：
   - 转录您的语音为文本
   - 对文本进行情感分析
   - 显示文本和对应的情感类别
3. 按 `Ctrl+C` 停止程序

## 输出示例

```
============================================================
文本: 我今天心情很好
情感: 惊喜
============================================================
```

## 注意事项

- 确保麦克风正常工作
- 需要有效的 DeepSeek API 密钥
- 首次运行可能需要下载语音识别模型
- 建议在安静环境中使用以获得更好的识别效果

## 依赖说明

- **openai**: DeepSeek API 客户端（兼容 OpenAI API）
- **PyAudio**: 音频输入/输出
- **faster-whisper**: 语音识别引擎
- **torch/torchaudio**: 深度学习框架
- 其他依赖请参考 `requirements.txt`

## 作者

Qianyuqianxun

## 更新日志

### v1.0.0
- 初始版本
- 实现实时语音转文本
- 集成 DeepSeek API 情感分析
- 支持自定义情感类别

